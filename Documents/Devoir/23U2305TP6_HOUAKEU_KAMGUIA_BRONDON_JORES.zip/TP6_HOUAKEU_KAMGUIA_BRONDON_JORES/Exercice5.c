#include<stdio.h> // Est la bibliotheque standart des entr�es sorties

	/* Programme C permettant de lire le tableau 10 coefficients et le tableau de 10
	notes d�un �tudiant et calculer la moyenne.  */

void main(){ // Fonction principale du programme
	int i,c; // D�claration des variables de type entier i un compteur et c initialis� � 0
	float s; // D�claration des variables de type r�els s et note initialis�es � 0
	float C[10]; // D�claration d'un tableau C de r�el de taille 10
	float N[10]; // D�claration d'un tableau N de r�el de taille 10
	float moy; //D�claration de la variable moyenne de type r�el
	s=0; c=0;
	for(i=0; i<10; i++){ // Pour i=1 (compteur i initialis� � 1), i<=10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("Entrer le Coefficient pour l'element %d  :  ", i+1); // Afficher la valeur de l'�l�ment du tableau des coefficients entr�s par l'utilisateur en les �num�rant �tape par �tape grace au compteur i
		scanf("%f", &C[i]); // Lire le tableau des 10 valeurs entr�es par l'utilisateur
		
		printf("Entrer la Note pour l'element %d  :  ", i+1); // Afficher la valeur de l'�l�ment du tableau des notes entr�s par l'utilisateur en les �num�rant �tape par �tape grace au compteur i
		scanf("%f", &N[i]);	// Lire le tableau des 10 valeurs entr�es par l'utilisateur	
		while((N[i]<0)||(N[i]>20)){
			printf("Entrer une note comprise entre 0 et 20  ");
			scanf("%f", &N[i]);	// Lire le tableau des 10 valeurs entr�es par l'utilisateur	
		}
	}
	
	printf("\n Votre tableau pour les Coefficients est de  :  "); // Afficher les valeurs du tableau des coefficients entr�es par l'utilisateur
	printf("\n");
	for(i=0; i<10; i++){ // Pour i=1 (compteur i initialis� � 1), i<=10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf(" |%f| ", C[i] ); // Afficher les valeurs du TABLEAU COEFFICIENTS
	}
	printf("\n");
	printf("\n Votre tableau pour les Notes est de  :  "); // Afficher les valeurs du tableau des notes entr�es par l'utilisateur
	printf("\n");
	for(i=0; i<10; i++){ // Pour i=1 (compteur i initialis� � 1), i<=10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf(" |%f| ", N[i] ); // Afficher les valeurs du TABLEAU NOTES
	}
	printf("\n");
	for(i=1; i<=10; i++){ // Pour i=1 (compteur i initialis� � 1), i<=10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		c = c + C[i]; // A la variable c on affecte c + le tableau de l'�l�ment i des coefficients
		s =s + (C[i]*N[i]); // A la variable s on affecte s + le tableau de l'�l�ment i des notes * le tableau de l'�l�ment i des coefficients
	}
	moy = s / c; // A la variable moyenne on affecte s / c
	printf("\n La moyenne de cet etudiant est de :  %f / 20 \n", moy); // Affiche la moyenne re�ue par l'�tudiant	
}
