#include <stdio.h> // Est la bibliotheque standart des entr�es sorties

	/* Programme C permettant de lire un tableau de 10 valeurs et de calculer la
	somme de toutes ces valeurs.  */

 void main(){ // Fonction principale du programme
	int i,s; // D�claration des variables de type entier i un compteur et somme initoalis� � z�ro 0
	int T[10]; // D�claration d'un tableau T d'entier fix� � 10
	s = 0;
	for(i=0; i<10; i++){ // Pour i=1 (compteur i initialis� � 1), i<=10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("Entrer la valeur de l'element %d du tableau: ", i+1); // Afficher la valeur de l'�l�ment du tableau en les �num�rant �l�ment par �l�ment grace au compteur i
		scanf("%d", &T[i]); // Lire le tableau des 10 valeurs entr�es par l'utilisateur
	}
	
	printf("Votre tableau est : "); // Afficher le tableau des valeurs entr�es par l'utilisateur
	for(i=0; i<10; i++){ // Pour i=1 (compteur i initialis� � 1), i<=10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("|%d| ", T[i]); // Afficher les valeurs du TABLEAU
	}
	
	printf("\n La somme de ce tableau est de: "); // Afficher la somme du tableau � calculer
	for(i=0; i<10; i++){ // Pour i=1 (compteur i initialis� � 1), i<=10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		s = s + T[i]; // A la variablr somme on affecte somme+les valeur du tableau qui sont T[i]
	}
	printf("%d  \n", s); // Afficher la somme calcul�e
}

