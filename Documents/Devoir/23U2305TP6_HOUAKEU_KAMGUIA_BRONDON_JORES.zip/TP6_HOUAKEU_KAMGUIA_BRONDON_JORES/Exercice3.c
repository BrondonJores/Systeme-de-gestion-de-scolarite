#include<stdio.h> // Est la bibliotheque standart des entr�es sorties

	/*Programme C permettant de lire un tableau de 10 valeurs et de faire la
	recherche du min, du max et leurs positions.   */

void main(){ // Fonction principale du programme
	int i, min, max, minI, maxI; // D�claration des variables de type entier i,min,max,minI et maxI 
	int T[10]; // D�claration d'un tableau T d'entier de taille 10
	
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 0), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("Entrer la valeur de l'element %d du tableau: \n", i+1); // Afficher la valeur de l'�l�ment du tableau en les �num�rant �l�ment par �l�ment grace au compteur i
		scanf("%d", &T[i]); // Lire le tableau des 10 valeurs entr�es par l'utilisateur
		
	}
	min=T[0]; // A la variable Min on affecte les valeurs du tableau de i qui seront entr�es par l'utilisateur
	max=T[0]; // A la variable Max on affecte les valeurs du tableau de i qui seront entr�es par l'utilisateur
	printf("\n Votre tableau est de: "); // Afficher le tableau des valeurs entr�es par l'utilisateur
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 0), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("|%d| ", T[i]); // Afficher les valeurs du TABLEAU
	}
	
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 0), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		if (T[i]<min){ // Si le Tableau de i est < � la variable min alors
			min=T[i]; // A la variable min on affecte le tableau de l'�l�ment i
			minI=i+1; // A la variable de la position la plus petite on affecte la position de i
		}
		else if (T[i]>max){ // Sinon si le Tableau de i est > � la variable max alors
			max=T[i]; // A la variable max on affecte le tableau de l'�l�ment i
			maxI=i+1; // A la variable de la position la plus grande on affecte la position de i
		}
	}
	
	printf("\n Le Minimum est: %d et sa Position est: %d ", min, minI); // Afficher le minimum et leur position des �l�ments du tableau entr� par l'utilisateur
	printf("\n Le Maximum est: %d et sa Position est: %d \n", max, maxI); // Afficher le maximum et leur position des �l�ments du tableau entr� par l'utilisateur
}
