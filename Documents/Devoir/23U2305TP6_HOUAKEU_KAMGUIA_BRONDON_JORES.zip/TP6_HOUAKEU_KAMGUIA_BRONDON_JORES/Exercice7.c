#include<stdio.h> // Est la bibliotheque standart des entr�es sorties

	/* Programme C qui permet de calculer de suites de 0 dans un tableau compos�
	uniquement de valeurs 1 et 0
	Exemple : V : 1 1 0 0 1 0 0 0 1 1 1 1 0 0 1
	Le nombre de suites de z�ro est 3   */

void main (){    
    int i,m;
    int C[16];
    m = 0; 
    for(i = 0; i<16; i++){
        printf("Entrer la valeur de l'�l�ment %d  ",i+1);
        scanf("%d",&C[i]);
        while((C[i]>1)||(C[i]<0)){
            printf("Entrer une valeur qui est 0 ou 1 ");
            scanf("%d", &C[i]);
        }
    }  
    printf("\n");
    printf("Votre Tableau est : \n");
    for(i = 0; i<16; i++){
        printf("| %d |",C[i]);
    }
    printf("\n");
    i = 0;
    while (i!=16){
        if((C[i]==0)&&(C[i+1]==0)&&(C[i-1]!=0)&&(i!=0)&&(i!=16)){       
            m = m+1;
        }else if((C[i]==0)&&(C[i+1]==0)&&(i==0)){
            m = m+1;
        }else if((C[i]==0)&&(C[i-1]==0)&&(i==16)){
            m = m;
        }
        i++;
    } 
    printf("Le nombre de suite de z�ro est : %d \n", m);
}
