#include<stdio.h> // Est la bibliotheque standart des entr�es sorties

	/* Programe pour la Conversion d�un nombre d�cimal en binaire. */

void main(){ // Fonction principale du programme
	int n,i,r; // D�claration des variables de type entier i un compteur et n
	int T[10]; // D�claration d'un tableau T d'entier de taille 10
	
	printf("Veillez entrer le nombre à convertir: "); // Affiche le nombre � convertir
	scanf("%d", &n); // Lire le nombre � convertir
	r = n;
	if(n<0){ // Si le nombre � convertir est n�gatif alors
		printf("\n La conversion d'un nombre negatif n'existe pas \n"); // Affiche que la conversion IMPOSSIBLE
	}
	
	else{ // Sinon
		for(i=0; n>0; i++){ // Pour i=0 (compteur i initialis� � 0), n>0 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
			T[i] = n%2; // A la variable T du tableau de i on affecte nombre � convertir modulo2
			n = n/2; // A la variable nombre � convertir on affecte nombre/2
		}
	
		printf("\n %d en binaire est égale à ", r); // Affiche le nombre binaire
		for(i=i-1; i>=0; i--){ // Pour i=i-1 (compteur i initialis� � i-1), i>=0 (condition d'arret du compteur i) et i-- (d�cr�mentation du compteur)
			printf("%d", T[i]); // Affiche le nombre binaire
		}
	}
	printf("\n"); // Affiche un d�callage � la ligne
}
