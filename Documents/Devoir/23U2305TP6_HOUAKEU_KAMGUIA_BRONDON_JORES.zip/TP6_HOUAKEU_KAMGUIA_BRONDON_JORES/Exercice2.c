#include<stdio.h>// Est la bibliotheque standart des entr�es sorties

	
void main(){ // Fonction principale du programme
	/*Programme C permettant de lire un tableau de 10 valeurs et d'afficher la
	position des z�ros et les comptabiliser.  */

	int i, s; // D�claration des variables de type entier i un compteur et k initialis� � z�ro 0
	int T[10]; // D�claration d'un tableau T d'entier de taille 10
	s = 0;
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 0), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("Entrer la valeur de l'element %d du tableau:   ", i+1); // Afficher la valeur de l'�l�ment du tableau en les �num�rant �l�ment par �l�ment grace au compteur i
		scanf("%d", &T[i]); // Lire le tableau des 10 valeurs entr�es par l'utilisateur
	}
	
	printf("\n Votre tableau est : "); // Afficher le tableau des valeurs entr�es par l'utilisateur
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 1), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("|%d| ", T[i]); // Afficher les valeurs du TABLEAU
	}
	
	printf("\n Les zeros dans ce tableau occupent les positions : "); // Afficher la position de z�ros dans le tableau entr� par l'utilisateur
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 1), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		if(T[i]==0){// Si le Tableau des valeurs de i est �gale � z�ros faire
			printf("%d ", i+1); // Afiiche la valeur des positions dee z�ros dans le tableau entr� par l'utilisateur
			s++; // On incr�mente le compteur k
		}
	}
	
	printf("\n Le nombre de zeros dans ce tableau est de:  %d \n" , s ); // Affiche le nombre de z�ros qui figurent dans le tableau
}
