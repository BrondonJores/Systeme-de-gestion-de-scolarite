#include<stdio.h> // Est la bibliotheque standart des entr�es sorties

	/* Programme C permettant de lire le tableau de 10 valeurs et v�rifier si le tableau est
	ordonn�    */

void main(){ // Fonction principale du programme
	int i, s; // D�claration des variables de type entier i un compteur et k initialis� � 1
	int T[10]; // D�claration d'un tableau T d'entier de taille 10
	s = 0;
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 0), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("Entrer la valeur de l'element %d du tableau: \n", i+1); // Afficher la valeur de l'�l�ment du tableau en les �num�rant �l�ment par �l�ment grace au compteur i
		scanf("%d", &T[i]); // Lire le tableau des 10 valeurs entr�es par l'utilisateur
	}
	
	printf("\n Votre tableau est de: "); // Afficher le tableau des valeurs entr�es par l'utilisateur
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 0), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		printf("|%d| ", T[i]); // Afficher les valeurs du TABLEAU
	}
	
	for(i=0; i<10; i++){ // Pour i=0 (compteur i initialis� � 1), i<10 (condition d'arret du compteur i) et i++ (incr�mentation du compteur)
		if (T[i]<T[i+1]){ // Si le tableau de la valeur de i est < au tableau de la valeur de i-1 alors
			s=s+1; // A la variable s on affecte s+1
		}else if (T[i]>T[i-1]){
			s=s+1; // A la variable s on affecte s+1 
		}
	}
	if(s == 10){ // Si k existe alors
		printf("\n Votre tableau est ordonn� \n"); // Affiche que le tableau est ordonn�
	}
	else{ // Sinon
		printf("\n Votre tableau n'est pas ordonn� \n"); // Affiche que le tableau n'est pas ordonn�
	}
}
